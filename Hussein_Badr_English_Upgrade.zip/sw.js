const CACHE_NAME = 'hbenglish-shell-v2';
const BASE_PATH = '/Hussien2009/';
const OFFLINE_URL = BASE_PATH + 'offline.html';
const PRECACHE = ["/Hussien2009/", "/Hussien2009/index.html", "/Hussien2009/placement-test.html", "/Hussien2009/skills-test.html", "/Hussien2009/paths.html", "/Hussien2009/flashcards.html", "/Hussien2009/dashboard.html", "/Hussien2009/about.html", "/Hussien2009/contact.html", "/Hussien2009/privacy.html", "/Hussien2009/terms.html", "/Hussien2009/404.html", "/Hussien2009/offline.html", "/Hussien2009/changelog.html", "/Hussien2009/lessons/index.html", "/Hussien2009/lessons/greetings.html", "/Hussien2009/lessons/numbers.html", "/Hussien2009/lessons/daily-routine.html", "/Hussien2009/lessons/present-simple.html", "/Hussien2009/lessons/at-the-restaurant.html", "/Hussien2009/lessons/at-the-airport.html", "/Hussien2009/blog/index.html", "/Hussien2009/blog/daily-english-practice.html", "/Hussien2009/blog/present-simple-guide.html", "/Hussien2009/assets/css/main.css", "/Hussien2009/assets/js/app.js", "/Hussien2009/assets/js/i18n.js", "/Hussien2009/assets/js/progress.js", "/Hussien2009/assets/js/share-card.js", "/Hussien2009/assets/js/test-engine.js", "/Hussien2009/assets/js/listening.js", "/Hussien2009/assets/js/speaking.js", "/Hussien2009/assets/js/srs.js", "/Hussien2009/assets/js/dashboard.js", "/Hussien2009/assets/js/contact-page.js", "/Hussien2009/assets/data/questions.json", "/Hussien2009/assets/data/lessons.json", "/Hussien2009/assets/data/flashcards.json", "/Hussien2009/assets/data/faq.json", "/Hussien2009/assets/data/paths.json", "/Hussien2009/manifest.webmanifest", "/Hussien2009/assets/icons/icon-192.png", "/Hussien2009/assets/icons/icon-512.png"];
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await Promise.allSettled(PRECACHE.map(url => cache.add(url)));
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('hbenglish-') && key !== CACHE_NAME).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin || !url.pathname.startsWith(BASE_PATH)) return;
  const isPage = request.mode === 'navigate' || /\.html?$/i.test(url.pathname);
  if (isPage) {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (response && response.ok) {
          const cache = await caches.open(CACHE_NAME);
          cache.put(request, response.clone()).catch(() => {});
        }
        return response;
      } catch {
        const cached = await caches.match(request) || await caches.match(url.pathname);
        if (cached) return cached;
        const fallback = await caches.match(OFFLINE_URL);
        if (fallback) return fallback;
        return new Response('Offline. Reconnect and try again.', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
      }
    })());
    return;
  }
  event.respondWith((async () => {
    const cached = await caches.match(request);
    if (cached) {
      fetch(request).then(response => { if (response && response.ok) caches.open(CACHE_NAME).then(cache => cache.put(request, response)); }).catch(() => {});
      return cached;
    }
    try {
      const response = await fetch(request);
      if (response && response.ok && response.type === 'basic') caches.open(CACHE_NAME).then(cache => cache.put(request, response.clone()));
      return response;
    } catch {
      if (request.destination === 'document') return (await caches.match(OFFLINE_URL)) || Response.error();
      return Response.error();
    }
  })());
});

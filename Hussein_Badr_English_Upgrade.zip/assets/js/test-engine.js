import { BASE_PATH, currentLanguage, tr } from './i18n.js';
import { recordTest } from './progress.js';
import { downloadResultCard, shareResult } from './share-card.js';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const SAVE_KEY = 'hbenglish:placement:v2';
const SKILL_NAMES = { grammar: 'القواعد', vocabulary: 'المفردات', reading: 'القراءة', listening: 'الاستماع', speaking: 'التحدث', writing: 'الكتابة' };
let allQuestions = []; let state = null; let voiceList = []; const playCounts = Object.create(null);
const levelOrder = ['A1','A2','B1','B2','C1'];
function normalise(value) { return String(value || '').toLowerCase().replace(/[^a-z0-9' ]/g, ' ').replace(/\s+/g, ' ').trim(); }
function safeParse(raw) { try { return JSON.parse(raw); } catch { return null; } }
function validSaved(v) { return !!(v && v.version === 2 && ['adaptive','full'].includes(v.mode) && Array.isArray(v.sequence) && v.sequence.length <= 40 && v.sequence.every(id => typeof id === 'string' && /^[A-Z0-9]{3}$/.test(id)) && v.answers && typeof v.answers === 'object' && !Array.isArray(v.answers) && Object.keys(v.answers).length <= 40 && Object.entries(v.answers).every(([id,a]) => /^[A-Z0-9]{3}$/.test(id) && a && typeof a === 'object' && typeof a.value === 'string' && a.value.length <= 500 && typeof a.answered === 'boolean' && typeof a.isCorrect === 'boolean') && typeof v.currentId === 'string' && /^[A-Z0-9]{3}$/.test(v.currentId)); }
function saveState() { if (!state) return; try { localStorage.setItem(SAVE_KEY, JSON.stringify({ version: 2, mode: state.mode, sequence: state.sequence, answers: state.answers, currentId: state.currentId, targetLevel: state.targetLevel, finished: state.finished, startedAt: state.startedAt })); } catch { showStatus('تعذّر حفظ التقدم محليًا؛ أكمل الاختبار دون إغلاق الصفحة.', 'Could not save progress locally; keep this page open.'); } }
function showStatus(ar, en = ar) { const node = $('[data-test-status]'); if (node) node.textContent = currentLanguage() === 'ar' ? ar : en; }
function questionById(id) { return allQuestions.find(item => item.id === id); }
function orderByLevel(items) { return [...items].sort((a,b) => levelOrder.indexOf(a.cefrLevel) - levelOrder.indexOf(b.cefrLevel) || a.id.localeCompare(b.id)); }
function initState(mode, restore = null) {
  if (restore) {
    state = { mode: restore.mode, sequence: restore.sequence, answers: restore.answers, currentId: restore.currentId, targetLevel: levelOrder.includes(restore.targetLevel) ? restore.targetLevel : 'A2', finished: false, startedAt: restore.startedAt || Date.now(), lastAdjustmentAt: 0 };
  } else {
    const first = mode === 'adaptive' ? allQuestions.find(q => q.cefrLevel === 'A2') : orderByLevel(allQuestions)[0];
    state = { mode, sequence: first ? [first.id] : [], answers: {}, currentId: first?.id || '', targetLevel: 'A2', finished: false, startedAt: Date.now(), lastAdjustmentAt: 0 };
  }
  $('[data-test-start-panel]')?.setAttribute('hidden',''); $('[data-test-workspace]')?.removeAttribute('hidden'); $('[data-test-results]')?.setAttribute('hidden','');
  renderQuestion(); saveState();
}
function nextAdaptiveQuestion() {
  const asked = new Set(state.sequence); const remaining = allQuestions.filter(q => !asked.has(q.id)); if (!remaining.length) return null;
  if (state.mode === 'full') return orderByLevel(remaining)[0];
  const recentIds = state.sequence.slice(-3); const recent = recentIds.map(id => ({q:questionById(id),a:state.answers[id]})).filter(x => x.q && x.a && x.a.answered);
  if (recent.length >= 3 && state.sequence.length >= state.lastAdjustmentAt + 3) {
    const ratio = recent.filter(x => x.a.isCorrect).length / recent.length;
    let index = levelOrder.indexOf(state.targetLevel);
    if (ratio >= .67) index = Math.min(levelOrder.length - 1, index + 1);
    else if (ratio <= .33) index = Math.max(0, index - 1);
    state.targetLevel = levelOrder[index]; state.lastAdjustmentAt = state.sequence.length;
  }
  const preferred = remaining.filter(q => q.cefrLevel === state.targetLevel);
  if (preferred.length) return preferred.sort((a,b) => a.difficultyWeight - b.difficultyWeight || a.id.localeCompare(b.id))[0];
  return remaining.sort((a,b) => Math.abs(levelOrder.indexOf(a.cefrLevel) - levelOrder.indexOf(state.targetLevel)) - Math.abs(levelOrder.indexOf(b.cefrLevel) - levelOrder.indexOf(state.targetLevel)) || a.id.localeCompare(b.id))[0];
}
function shouldStopAdaptive() {
  if (state.mode !== 'adaptive' || state.sequence.length < 20) return false;
  const last = state.sequence.slice(-10).map(id => state.answers[id]).filter(a => a && a.answered);
  if (last.length < 10) return false;
  const ratio = last.filter(a => a.isCorrect).length / last.length;
  return ratio >= .9 || ratio <= .1;
}
function answered(q) { return !!(state.answers[q.id] && state.answers[q.id].answered); }
function renderQuestion() {
  const q = questionById(state.currentId); if (!q) { finishTest(); return; }
  const host = $('[data-question-host]'); if (!host) return;
  host.replaceChildren();
  const totalDisplay = state.mode === 'adaptive' ? `سؤال ${state.sequence.length}` : `سؤال ${state.sequence.indexOf(q.id)+1} من ${allQuestions.length}`;
  const head = document.createElement('div'); head.className = 'question-meta';
  const level = document.createElement('span'); level.className = 'eyebrow'; level.textContent = `${q.cefrLevel} · ${SKILL_NAMES[q.skill] || q.skill}`;
  const count = document.createElement('span'); count.textContent = currentLanguage() === 'ar' ? totalDisplay : `Question ${state.sequence.indexOf(q.id)+1} of ${state.mode === 'adaptive' ? 'adaptive test' : allQuestions.length}`;
  head.append(level,count); host.append(head);
  if (q.passage) { const passage = document.createElement('blockquote'); passage.className = 'reading-passage'; passage.textContent = q.passage; host.append(passage); }
  const prompt = document.createElement('h2'); prompt.className = 'question-prompt'; prompt.textContent = q.prompt; host.append(prompt);
  const report = document.createElement('button'); report.type = 'button'; report.className = 'text-button'; report.textContent = 'الإبلاغ عن خطأ في هذا السؤال'; report.addEventListener('click', () => { location.href = BASE_PATH + 'contact.html?subject=' + encodeURIComponent('بلاغ عن سؤال ' + q.id) + '&question=' + encodeURIComponent(q.id); }); host.append(report);
  if (q.skill === 'listening') {
    const listen = document.createElement('button'); listen.type='button'; listen.className='button button-secondary'; listen.dataset.playQuestion = q.id; listen.textContent = `▶ استمع إلى السؤال (${playCounts[q.id] || 0}/2)`; listen.disabled = (playCounts[q.id] || 0) >= 2; listen.addEventListener('click', () => playQuestion(q, listen)); host.append(listen);
  }
  if (q.skill === 'speaking') {
    const hint = document.createElement('p'); hint.className='help-text'; hint.textContent = 'يمكنك كتابة إجابتك أو استخدام التعرف على الكلام. التقييم تقريبي ويعتمد على كلمات متطابقة، لا على حكم بشري على النطق.'; host.append(hint);
    const textarea=document.createElement('textarea'); textarea.rows=3; textarea.maxLength=500; textarea.placeholder='Type your answer in English…'; textarea.setAttribute('aria-label','إجابتك باللغة الإنجليزية'); textarea.dataset.speakingAnswer=''; textarea.value=state.answers[q.id]?.value || ''; host.append(textarea);
    const mic=document.createElement('button'); mic.type='button'; mic.className='button button-secondary'; mic.textContent='🎙 أجب بالصوت'; mic.addEventListener('click', () => recognizeInto(textarea,mic)); host.append(mic);
  } else {
    const choices=document.createElement('div'); choices.className='answer-options'; choices.setAttribute('role','radiogroup'); choices.setAttribute('aria-label','خيارات الإجابة');
    q.options.forEach((option,index) => {
      const label=document.createElement('label'); label.className='answer-option';
      const input=document.createElement('input'); input.type='radio'; input.name=`answer-${q.id}`; input.value=String(index); input.checked=state.answers[q.id]?.value === option;
      const text=document.createElement('span'); text.textContent=option; label.append(input,text); choices.append(label);
      input.addEventListener('change', () => saveAnswer(q, option));
    }); host.append(choices);
  }
  const existing=state.answers[q.id]; if (existing?.answered) showFeedback(q, existing);
  const n=state.sequence.indexOf(q.id)+1; const progress=state.mode==='adaptive' ? Math.min(100,n/40*100) : n/40*100;
  const bar=$('[data-test-progress-fill]'); if (bar) bar.style.width=`${progress}%`;
  const counter=$('[data-test-counter]'); if (counter) counter.textContent=state.mode==='adaptive' ? `${n} / 40 (adaptive)` : `${n} / ${allQuestions.length}`;
  const previous=$('[data-test-previous]'); if (previous) previous.disabled=state.sequence.indexOf(q.id) <= 0;
  const next=$('[data-test-next]'); if (next) next.textContent = state.mode==='adaptive' && n >=20 && shouldStopAdaptive() ? 'عرض النتيجة' : (n >= allQuestions.length ? 'عرض النتيجة' : 'التالي ←');
  saveState();
}
function playQuestion(q, button) {
  const already = playCounts[q.id] || 0; if (already >= 2) { showStatus('يسمح بتشغيل كل سؤال استماع مرتين فقط. أجب بناءً على ما سمعته.', 'Each listening item can be played only twice. Answer from what you heard.'); return; }
  const count = already + 1; playCounts[q.id] = count; button.textContent=`▶ استمع إلى السؤال (${count}/2)`; button.disabled = count >= 2;
  const utteranceText=q.transcript || q.prompt;
  if (q.audio) { const audio=new Audio(`${BASE_PATH}${q.audio}`); audio.play().catch(() => speakFallback(utteranceText)); }
  else speakFallback(utteranceText);
}
function speakFallback(text) {
  if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') { showStatus(tr('speechUnsupported')); return; }
  const synth=speechSynthesis; synth.cancel(); const utterance=new SpeechSynthesisUtterance(text); utterance.lang='en-US';
  const voices=synth.getVoices(); const choice=voices.find(v => /^en-US$/i.test(v.lang)) || voices.find(v => /^en(-|_)/i.test(v.lang)); if (choice) utterance.voice=choice;
  utterance.onerror=()=>showStatus(tr('speechUnsupported')); if (!voices.length) showStatus(tr('speechVoicesMissing')); synth.speak(utterance);
}
function recognizeInto(textarea,button) {
  const Recognition=window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) { showStatus('التعرف على الكلام غير مدعوم هنا. اكتب إجابتك في الحقل.', 'Speech recognition is unavailable. Type your answer instead.'); textarea.focus(); return; }
  const rec=new Recognition(); rec.lang='en-US'; rec.interimResults=false; rec.maxAlternatives=1; button.disabled=true; button.textContent='يستمع الآن…';
  rec.onresult=event=>{ textarea.value=event.results?.[0]?.[0]?.transcript || ''; textarea.dispatchEvent(new Event('input',{bubbles:true})); };
  rec.onerror=event=>showStatus(`تعذّر التعرف على الصوت (${String(event.error || 'unknown')}). يمكنك كتابة الإجابة.`);
  rec.onend=()=>{button.disabled=false;button.textContent='🎙 أجب بالصوت';}; try { rec.start(); } catch { button.disabled=false; showStatus('لم يبدأ الميكروفون. تحقق من الإذن ثم حاول مجددًا.'); }
}
function evaluate(q, value) {
  if (q.skill !== 'speaking') return value === q.correctAnswer;
  const text=normalise(value); if (!text) return false;
  const accepted=(q.acceptedAnswers || []).map(normalise);
  if (accepted.some(phrase => phrase && (text.includes(phrase) || phrase.includes(text)))) return true;
  const keyTokens=normalise(q.correctAnswer).split(' ').filter(t=>t.length>2); const textTokens=new Set(text.split(' '));
  const overlap=keyTokens.filter(t=>textTokens.has(t)).length / Math.max(1,keyTokens.length); return overlap >= .35;
}
function saveAnswer(q,value) {
  const item={value,answered:true,isCorrect:evaluate(q,value),answeredAt:Date.now()}; state.answers[q.id]=item; saveState(); showFeedback(q,item);
}
function showFeedback(q,item) {
  let node=$('[data-answer-feedback]'); if (!node) { node=document.createElement('div'); node.className='feedback-panel'; node.dataset.answerFeedback=''; node.setAttribute('aria-live','polite'); $('[data-question-host]')?.append(node); }
  const correctAnswer = q.skill==='speaking' ? 'إجابة نموذجية: '+q.options[0] : `الإجابة الصحيحة: ${q.correctAnswer}`;
  node.textContent = `${item.isCorrect ? '✓ إجابة مقبولة. ' : '✗ راجع الإجابة. '}${correctAnswer}. ${q.explanationAr}`;
}
function saveCurrentInput() {
  const q=questionById(state.currentId); if (!q || q.skill!=='speaking') return;
  const area=$('[data-speaking-answer]'); if (area && area.value.trim()) saveAnswer(q,area.value.trim());
}
function moveNext() {
  saveCurrentInput();
  if (state.mode==='adaptive' && shouldStopAdaptive()) { finishTest(); return; }
  const currentIndex=state.sequence.indexOf(state.currentId);
  if (currentIndex < state.sequence.length-1) { state.currentId=state.sequence[currentIndex+1]; renderQuestion(); return; }
  if (state.sequence.length>=allQuestions.length) { finishTest(); return; }
  const next=nextAdaptiveQuestion(); if (!next) { finishTest(); return; }
  state.sequence.push(next.id); state.currentId=next.id; renderQuestion();
}
function movePrevious() {
  saveCurrentInput(); const i=state.sequence.indexOf(state.currentId); if (i>0) {state.currentId=state.sequence[i-1];renderQuestion();}
}
function levelFromPercent(percent) { return percent>=88?'C1':percent>=73?'B2':percent>=57?'B1':percent>=38?'A2':'A1'; }
function calculateResult() {
  const administered=state.sequence.map(questionById).filter(Boolean); let earned=0,total=0;
  const bySkill={}; const skillCount={};
  for (const q of administered) { const max=Number(q.difficultyWeight)||1; total+=max; const a=state.answers[q.id]; const correct=!!(a && a.answered && a.isCorrect); if(correct) earned+=max; bySkill[q.skill] ||= {earned:0,total:0,answered:0}; bySkill[q.skill].total+=max; bySkill[q.skill].answered++; if(correct)bySkill[q.skill].earned+=max; }
  for (const [key,value] of Object.entries(bySkill)) { value.percent=value.total?Math.round(value.earned/value.total*100):0; value.level=levelFromPercent(value.percent); value.label=SKILL_NAMES[key] || key; skillCount[key]=value.percent; }
  const percent=total?Math.round(earned/total*100):0; const level=levelFromPercent(percent);
  const strengths=Object.values(bySkill).filter(x=>x.percent>=70).sort((a,b)=>b.percent-a.percent); const weaknesses=Object.values(bySkill).filter(x=>x.percent<55).sort((a,b)=>a.percent-b.percent);
  return {level,percent,bySkill:skillCount,skills:bySkill,strengths:strengths.map(x=>x.label),weaknesses:weaknesses.map(x=>x.label),answered:administered.filter(q=>state.answers[q.id]?.answered).length,total:administered.length,mode:state.mode};
}
function finishTest() {
  if (!state || state.finished) return; saveCurrentInput(); state.finished=true; saveState();
  const result=calculateResult(); recordTest(result);
  $('[data-test-workspace]')?.setAttribute('hidden',''); const panel=$('[data-test-results]'); panel?.removeAttribute('hidden'); if (!panel) return;
  panel.replaceChildren();
  const title=document.createElement('h2'); title.textContent='نتيجتك التقديرية'; panel.append(title);
  const hero=document.createElement('div'); hero.className='result-hero'; const level=document.createElement('div'); level.className='result-level'; level.textContent=result.level; const percent=document.createElement('p'); percent.textContent=`${result.percent}% — إجابة موزونة`; hero.append(level,percent); panel.append(hero);
  const summary=document.createElement('p'); summary.textContent=`أجبت عن ${result.answered} من ${result.total} سؤالًا تم عرضها. المستوى تقديري وقد يختلف باختلاف مهام الكلام والاستماع والمتصفح.`; panel.append(summary);
  const table=document.createElement('div'); table.className='skill-score-grid';
  for (const value of Object.values(result.skills)) { const card=document.createElement('article'); card.className='score-card'; const h=document.createElement('h3'); h.textContent=value.label; const strong=document.createElement('strong'); strong.textContent=`${value.percent}%`; const p=document.createElement('p'); p.textContent=`مستوى تقريبي: ${value.level}`; card.append(h,strong,p); table.append(card); } panel.append(table);
  const good=document.createElement('p'); good.textContent='نقاط قوة: '+(result.strengths.join('، ')||'تابع التدريب للحصول على صورة أوضح.'); panel.append(good);
  const weak=document.createElement('p'); weak.textContent='مجالات للتحسين: '+(result.weaknesses.join('، ')||'استمر في الممارسة المنتظمة.'); panel.append(weak);
  const plan=document.createElement('section'); plan.className='study-plan'; const planTitle=document.createElement('h3'); planTitle.textContent='خطة تعلّم مقترحة لمدة 30 يومًا'; plan.append(planTitle);
  const planText=document.createElement('p'); planText.textContent='الأيام 1–7: أكمل التحيات والأرقام. الأيام 8–14: تدرب على الروتين والمضارع البسيط. الأيام 15–21: راجع المطعم والسفر. الأيام 22–30: كرر اختبار المهارات والبطاقات وراجع أخطاءك.'; plan.append(planText);
  const links=document.createElement('div'); links.className='button-row'; [['درس التحيات','lessons/greetings.html'],['الأرقام والوقت','lessons/numbers.html'],['الروتين اليومي','lessons/daily-routine.html'],['المضارع البسيط','lessons/present-simple.html'],['في المطعم','lessons/at-the-restaurant.html'],['في المطار','lessons/at-the-airport.html']].forEach(([label,url])=>{const a=document.createElement('a');a.className='button button-secondary';a.href=BASE_PATH+url;a.textContent=label;links.append(a);}); plan.append(links); panel.append(plan);
  const cta=document.createElement('a'); cta.className='button button-primary'; cta.href='https://t.me/HBM20091'; cta.target='_blank'; cta.rel='noopener noreferrer'; cta.textContent='تابع قناة Telegram لممارسة أكثر'; cta.setAttribute('aria-label','تابع قناة Telegram بعد النتيجة (يفتح في تبويب جديد)'); panel.append(cta);
  const share=document.createElement('div'); share.className='button-row';
  for (const [label,method] of [['تنزيل بطاقة النتيجة','download'],['مشاركة عبر WhatsApp','whatsapp'],['مشاركة عبر Telegram','telegram'],['مشاركة عبر X','x'],['نسخ رابط الموقع','copy']]) { const b=document.createElement('button');b.type='button';b.className='button button-secondary';b.textContent=label;b.dataset.shareResult='';b.dataset.shareMethod=method;b.dataset.result=JSON.stringify(result);b.addEventListener('click',async()=>{try{if(method==='download')await downloadResultCard(result);else await shareResult(result,method);}catch{showStatus('تعذرت المشاركة هنا. جرّب نسخ الرابط أو تنزيل البطاقة.');}});share.append(b); } panel.append(share);
  const review=document.createElement('section'); review.className='review-list'; const rh=document.createElement('h3'); rh.textContent='مراجعة الإجابات والشرح'; review.append(rh);
  for (const q of administered) { const details=document.createElement('details'); const summary=document.createElement('summary'); const a=state.answers[q.id]; summary.textContent=`${q.id} — ${q.prompt} ${a?.isCorrect?'✓':'✗'}`; const body=document.createElement('div'); const answer=document.createElement('p'); answer.textContent=`إجابتك: ${a?.value ?? 'لم تُجب'}`; const correct=document.createElement('p'); correct.textContent=`الإجابة الصحيحة/النموذجية: ${q.correctAnswer}`; const why=document.createElement('p'); why.textContent=q.explanationAr; const report=document.createElement('button'); report.type='button';report.className='text-button';report.textContent='الإبلاغ عن خطأ في السؤال';report.dataset.reportQuestion=q.id;report.addEventListener('click',()=>location.href=BASE_PATH+'contact.html?subject='+encodeURIComponent('بلاغ عن سؤال '+q.id)+'&question='+encodeURIComponent(q.id));body.append(answer,correct,why,report);details.append(summary,body);review.append(details); }
  panel.append(review);
  const retake=document.createElement('button');retake.type='button';retake.className='button button-primary';retake.textContent='إعادة الاختبار';retake.addEventListener('click',()=>{try{localStorage.removeItem(SAVE_KEY);}catch{};state=null;renderStart();});panel.append(retake);
  showStatus('حُفظت النتيجة محليًا على هذا الجهاز.');
}
function renderStart() {
  $('[data-test-start-panel]')?.removeAttribute('hidden'); $('[data-test-workspace]')?.setAttribute('hidden',''); $('[data-test-results]')?.setAttribute('hidden','');
  const saved=safeParse((()=>{try{return localStorage.getItem(SAVE_KEY)||'null';}catch{return 'null';}})());
  const resume=$('[data-test-resume]'); if(resume) { if(validSaved(saved)&&!saved.finished){resume.hidden=false;resume.onclick=()=>initState(saved.mode,saved);} else resume.hidden=true; }
}
async function init() {
  const status=$('[data-test-status]'); if(status) status.textContent='يتم تجهيز الأسئلة…';
  try {
    const response=await fetch(`${BASE_PATH}assets/data/questions.json`,{cache:'no-cache'}); if(!response.ok)throw new Error('questions unavailable');
    const data=await response.json(); if(!Array.isArray(data)||data.length!==40||new Set(data.map(q=>q.id)).size!==40)throw new Error('invalid question data');
    allQuestions=data.filter(q=>q && typeof q.id==='string' && ['grammar','vocabulary','reading','listening','speaking','writing'].includes(q.skill) && levelOrder.includes(q.cefrLevel) && Array.isArray(q.options) && typeof q.correctAnswer==='string');
    if(allQuestions.length!==40)throw new Error('invalid question fields');
    $('[data-test-start-adaptive]')?.addEventListener('click',()=>initState('adaptive'));
    $('[data-test-start-full]')?.addEventListener('click',()=>initState('full'));
    $('[data-test-next]')?.addEventListener('click',moveNext); $('[data-test-previous]')?.addEventListener('click',movePrevious);
    document.addEventListener('keydown',event=>{if(!state||state.finished||event.altKey||event.ctrlKey||event.metaKey||event.target.matches('textarea,input,select'))return;if(event.key==='ArrowRight')moveNext();if(event.key==='ArrowLeft')movePrevious();});
    document.addEventListener('input',event=>{if(event.target.matches('[data-speaking-answer]')&&state){const q=questionById(state.currentId);if(q){state.answers[q.id]={value:event.target.value,answered:false,isCorrect:false};saveState();}}});
    renderStart(); if(status)status.textContent='اختر الاختبار الكامل أو الوضع التكيفي. تُحفظ إجاباتك على هذا الجهاز.';
  } catch(error) { if(status)status.textContent='تعذّر تحميل الأسئلة. افتح الموقع المنشور أو تحقق من وجود assets/data/questions.json ثم أعد تحميل الصفحة.'; const buttons=$$('[data-test-start-adaptive],[data-test-start-full]');buttons.forEach(b=>b.disabled=true); }
}
init();

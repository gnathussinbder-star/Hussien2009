import { applyLanguage, currentLanguage, tr, BASE_PATH } from './i18n.js';
import { getProgress, completeLesson, exportAll, resetAll, getOnboarding, saveOnboarding } from './progress.js';
import { shareResult, downloadResultCard } from './share-card.js';

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
function toast(message) { const node = $('[data-toast]'); if (!node) return; node.textContent = message; node.classList.add('is-visible'); window.setTimeout(() => node.classList.remove('is-visible'), 3600); }
function storageSet(key, value) { try { localStorage.setItem(key, value); return true; } catch { return false; } }
function applyTheme(theme) {
  const selected = theme === 'light' ? 'light' : 'dark'; document.documentElement.dataset.theme = selected;
  storageSet('hbenglish:theme', selected);
  $$('[data-theme-toggle]').forEach(button => button.setAttribute('aria-label', currentLanguage() === 'ar' ? `المظهر الحالي ${selected === 'dark' ? 'داكن' : 'فاتح'}؛ اضغط للتبديل` : `Current ${selected} theme; press to toggle`));
}
function initHeader() {
  const lang = applyLanguage(currentLanguage());
  $$('[data-language-toggle]').forEach(btn => btn.addEventListener('click', () => applyLanguage(currentLanguage() === 'ar' ? 'en' : 'ar')));
  let theme = 'dark'; try { theme = localStorage.getItem('hbenglish:theme') || (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark'); } catch { /* Theme stays dark. */ }
  applyTheme(theme);
  $$('[data-theme-toggle]').forEach(btn => btn.addEventListener('click', () => applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark')));
  $$('[data-menu-toggle]').forEach(btn => btn.addEventListener('click', () => {
    const nav = $('#primary-nav'); if (!nav) return; const open = btn.getAttribute('aria-expanded') !== 'true';
    btn.setAttribute('aria-expanded', String(open)); nav.classList.toggle('is-open', open); btn.setAttribute('aria-label', open ? (currentLanguage() === 'ar' ? 'إغلاق القائمة' : 'Close navigation') : (currentLanguage() === 'ar' ? 'فتح القائمة' : 'Open navigation'));
  }));
  const year = $('[data-current-year]'); if (year) year.textContent = String(new Date().getFullYear());
}
function speak(text, voiceHint = 'en-US', rate = 1) {
  if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') { toast(tr('speechUnsupported')); return; }
  const synth = window.speechSynthesis; synth.cancel(); const utterance = new SpeechSynthesisUtterance(String(text || '').slice(0, 1200));
  utterance.lang = voiceHint === 'en-GB' ? 'en-GB' : 'en-US'; utterance.rate = Math.max(.65, Math.min(1.1, Number(rate) || 1));
  const voices = synth.getVoices(); const english = voices.filter(v => /^en(-|_)/i.test(v.lang));
  const wanted = english.find(v => v.lang.toLowerCase() === utterance.lang.toLowerCase()) || english.find(v => v.lang.toLowerCase().startsWith(utterance.lang.slice(0,2).toLowerCase())) || english[0];
  if (wanted) utterance.voice = wanted;
  utterance.onerror = () => toast(tr('speechUnsupported'));
  if (!voices.length && synth.getVoices().length === 0) { toast(tr('speechVoicesMissing')); }
  synth.speak(utterance);
}
function initSpeechAndQuizzes() {
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-speak]'); if (button) { speak(button.getAttribute('data-speak'), button.getAttribute('data-voice') || 'en-US', button.getAttribute('data-rate') || 1); }
  });
  $$('[data-check-quiz]').forEach(button => button.addEventListener('click', () => {
    const quiz = button.closest('.mini-quiz'); if (!quiz) return; const questions = $$('.quiz-question', quiz); let right = 0; let unanswered = false;
    questions.forEach((q, index) => {
      const selected = $('input[type="radio"]:checked', q); const feedback = $('.quiz-feedback', q); const answer = Number(q.dataset.answer);
      if (!selected) { unanswered = true; if (feedback) feedback.textContent = currentLanguage() === 'ar' ? 'اختر إجابة لهذا السؤال.' : 'Choose an answer for this question.'; return; }
      const correct = Number(selected.value) === answer; if (correct) right++;
      if (feedback) feedback.textContent = `${correct ? '✓ ' : '✗ '}${q.dataset.why || (correct ? tr('quizCorrect') : tr('quizWrong'))}`;
      q.classList.toggle('is-correct', correct); q.classList.toggle('is-wrong', !correct);
    });
    const output = $('.quiz-summary', quiz); if (output) output.textContent = unanswered ? (currentLanguage() === 'ar' ? `أجبت عن ${questions.filter(q => $('input:checked',q)).length} من ${questions.length}. أكمل الباقي.` : `Answered ${questions.filter(q => $('input:checked',q)).length} of ${questions.length}. Finish the rest.`) : (currentLanguage() === 'ar' ? `نتيجتك: ${right} من ${questions.length}.` : `Your score: ${right} out of ${questions.length}.`);
  }));
  $$('[data-complete-lesson]').forEach(button => button.addEventListener('click', () => {
    const id = button.dataset.completeLesson; completeLesson(id); button.disabled = true; button.textContent = currentLanguage() === 'ar' ? '✓ تم إكمال الدرس' : '✓ Lesson completed'; toast(currentLanguage() === 'ar' ? 'أُضيف الدرس إلى تقدمك المحلي (+10 نقاط).' : 'Lesson added to local progress (+10 points).');
  }));
}
function initExportReset() {
  $$('[data-export-progress]').forEach(button => button.addEventListener('click', () => {
    const data = exportAll(); const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }); const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'hussein-badr-progress.json'; a.click(); URL.revokeObjectURL(url); toast(tr('exportDone'));
  }));
  $$('[data-reset-progress]').forEach(button => button.addEventListener('click', () => {
    const okay = confirm(currentLanguage() === 'ar' ? 'هل تريد حذف كل تقدمك وبطاقات المراجعة المحفوظة على هذا الجهاز؟ لا يمكن التراجع.' : 'Delete all local progress and flashcard review data on this device? This cannot be undone.');
    if (okay) { resetAll(); location.reload(); }
  }));
}
function initShare() {
  $$('[data-share-result]').forEach(button => button.addEventListener('click', async () => {
    const raw = safeParse(button.dataset.result || '{}'); const result = raw && typeof raw === 'object' ? raw : { level: 'A1', percent: 0, bySkill: {} };
    try {
      const method = button.dataset.shareMethod || 'native';
      if (method === 'download') { await downloadResultCard(result); return; }
      await shareResult(result, method); if (method === 'copy' || (!navigator.share && method === 'native')) toast(tr('linkCopied'));
    } catch (err) { toast(currentLanguage() === 'ar' ? 'تعذّرت المشاركة من هذا المتصفح. استخدم نسخ الرابط.' : 'Sharing is unavailable here. Use copy link instead.'); }
  }));
}
function safeParse(value) { try { return JSON.parse(value); } catch { return null; } }
function initDailyTip() {
  const node = $('[data-tip-of-day]'); if (!node) return;
  const tips = currentLanguage() === 'ar' ? ['قل جملة إنجليزية واحدة بصوت عالٍ ثم أعدها بإيقاع طبيعي.','راجع خمس بطاقات قديمة قبل تعلّم كلمات جديدة.','استمع إلى جملة قصيرة مرتين: مرة للمعنى ومرة للنطق.','اكتب ثلاث جمل عن يومك باستخدام المضارع البسيط.','تعلّم عبارة كاملة بدل حفظ كلمة منفردة.'] : ['Say one English sentence aloud, then repeat it naturally.','Review five old flashcards before adding new words.','Listen to one short sentence twice: once for meaning and once for pronunciation.','Write three sentences about your day in the present simple.','Learn a complete phrase instead of an isolated word.'];
  const index = Math.floor(Date.now() / 86400000) % tips.length; node.textContent = tips[index];
}
function initOnboarding() {
  const form = $('[data-onboarding-form]'); if (!form) return;
  const existing = getOnboarding(); const box = $('[data-onboarding-panel]');
  if (existing && box) { box.hidden = true; const summary = $('[data-onboarding-summary]'); if (summary) summary.textContent = currentLanguage() === 'ar' ? `هدفك: ${goalAr(existing.goal)} — ${existing.minutes} دقائق يوميًا` : `Goal: ${existing.goal}; ${existing.minutes} minutes per day`; }
  form.addEventListener('submit', event => {
    event.preventDefault(); const fd = new FormData(form); const value = { goal: String(fd.get('goal')), level: String(fd.get('level')), minutes: String(fd.get('minutes')) };
    if (!saveOnboarding(value)) { toast(tr('error')); return; } if (box) box.hidden = true;
    const summary = $('[data-onboarding-summary]'); if (summary) summary.textContent = currentLanguage() === 'ar' ? `تم حفظ هدفك: ${goalAr(value.goal)} — ${value.minutes} دقائق يوميًا.` : `Saved your goal: ${value.goal}, ${value.minutes} minutes/day.`; toast(tr('saved'));
  });
}
function goalAr(goal) { return ({conversation:'المحادثة',travel:'السفر',work:'العمل',exam:'الاختبارات',general:'التعلّم العام'})[goal] || 'التعلّم'; }
function initContact() {
  const form = $('[data-contact-form]'); if (!form) return;
  form.addEventListener('submit', event => {
    event.preventDefault(); const fd = new FormData(form); if (String(fd.get('website') || '').trim()) { toast(currentLanguage() === 'ar' ? 'تعذّر إرسال الطلب.' : 'Unable to submit this request.'); return; }
    let last = 0; try { last = Number(localStorage.getItem('hbenglish:contact:last') || 0); } catch { /* rate limiting remains best effort */ }
    if (Date.now() - last < 60000) { toast(currentLanguage() === 'ar' ? 'يرجى الانتظار دقيقة قبل إعداد رسالة أخرى.' : 'Please wait one minute before preparing another message.'); return; }
    const name = String(fd.get('name') || '').trim().slice(0, 80); const email = String(fd.get('email') || '').trim().slice(0, 160); const subject = String(fd.get('subject') || '').trim().slice(0, 140); const message = String(fd.get('message') || '').trim().slice(0, 4000);
    if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || subject.length < 3 || message.length < 10) { toast(currentLanguage() === 'ar' ? 'يرجى مراجعة الاسم والبريد والعنوان والرسالة.' : 'Check your name, email, subject, and message.'); return; }
    try { localStorage.setItem('hbenglish:contact:last', String(Date.now())); } catch { /* The mail client remains usable. */ }
    const mailbox = String.fromCharCode(103,110,97,116,104,117,115,115,105,110,98,100,101,114,64,103,109,97,105,108,46,99,111,109);
    const body = `Name: ${name}\nReply email: ${email}\n\n${message}`; location.href = `mailto:${mailbox}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    const status = $('[data-contact-status]'); if (status) status.textContent = currentLanguage() === 'ar' ? 'سيُفتح تطبيق البريد لديك لإرسال الرسالة. لم تُرسل البيانات إلى الموقع.' : 'Your mail app will open to send the message. The site has not transmitted your data.';
  });
}
function initNewsletter() {
  const form = $('[data-newsletter-form]'); if (!form) return;
  form.addEventListener('submit', event => {
    event.preventDefault(); const input = $('[name="email"]', form); const address = String(input?.value || '').trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(address)) { toast(currentLanguage() === 'ar' ? 'أدخل بريدًا إلكترونيًا صحيحًا.' : 'Enter a valid email address.'); return; }
    const mailbox = String.fromCharCode(103,110,97,116,104,117,115,115,105,110,98,100,101,114,64,103,109,97,105,108,46,99,111,109);
    const subject = currentLanguage() === 'ar' ? 'طلب الاشتراك في تذكير تعلم الإنجليزية' : 'English practice reminder request';
    const body = `Email: ${address}\nPlease let me know about English learning updates.\n\nThis message was created locally by the website.`;
    const note = $('[data-newsletter-status]'); if (note) note.textContent = currentLanguage() === 'ar' ? 'سيُفتح تطبيق البريد لتراجع الطلب وترسله. لا توجد قائمة اشتراك تلقائية على الموقع.' : 'Your mail app will open so you can review and send the request. No mailing list is run by this site.';
    location.href = `mailto:${mailbox}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  });
}
function initReload() { $$('[data-reload-page]').forEach(button => button.addEventListener('click', () => location.reload())); }

function initPaths() {
  const target = $('[data-path-progress]'); if (!target) return; const progress = getProgress();
  $$('[data-path-card]', target).forEach(card => { const ids = (card.dataset.lessonIds || '').split(',').filter(Boolean); const count = ids.filter(id => progress.lessonsCompleted.includes(id)).length; const percent = ids.length ? Math.round(100 * count / ids.length) : 0; const fill = $('.progress-fill', card); const label = $('.path-percent', card); if (fill) fill.style.width = `${percent}%`; if (label) label.textContent = `${percent}%`; });
}
function initInstall() {
  let deferred = null; window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); deferred = event; const btn = $('[data-install-app]'); if (btn) btn.hidden = false; });
  $$('[data-install-app]').forEach(btn => btn.addEventListener('click', async () => { if (!deferred) { toast(currentLanguage() === 'ar' ? 'من قائمة المتصفح اختر «إضافة إلى الشاشة الرئيسية».' : 'Use your browser menu and choose “Add to Home screen”.'); return; } deferred.prompt(); await deferred.userChoice; deferred = null; btn.hidden = true; }));
}
function initFeedbackLinks() { $$('[data-report-question]').forEach(btn => btn.addEventListener('click', () => { const id = btn.dataset.reportQuestion || 'unknown'; location.href = `${BASE_PATH}contact.html?subject=${encodeURIComponent('بلاغ عن سؤال ' + id)}&question=${encodeURIComponent(id)}`; })); }

initHeader(); initSpeechAndQuizzes(); initExportReset(); initShare(); initDailyTip(); initOnboarding(); initContact(); initNewsletter(); initPaths(); initInstall(); initFeedbackLinks(); initReload();
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) { window.addEventListener('load', () => navigator.serviceWorker.register(`${BASE_PATH}sw.js`, { scope: BASE_PATH }).catch(() => { /* Core pages still work without PWA support. */ })); }

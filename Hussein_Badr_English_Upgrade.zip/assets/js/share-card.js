import { BASE_PATH } from './i18n.js';
export function makeShareText(result) {
  const url = `${location.origin}${BASE_PATH}`;
  return `نتيجتي التقديرية في اختبار Hussein Badr English: ${result.level} (${result.percent}%). جرّب الاختبار: ${url}`;
}
export async function downloadResultCard(result) {
  const canvas = document.createElement('canvas'); canvas.width = 1200; canvas.height = 675;
  const ctx = canvas.getContext('2d'); if (!ctx) throw new Error('Canvas is not available');
  ctx.fillStyle = '#101a3a'; ctx.fillRect(0, 0, canvas.width, canvas.height);
  const gradient = ctx.createLinearGradient(0, 0, 1200, 675); gradient.addColorStop(0, '#152a57'); gradient.addColorStop(1, '#0d142d');
  ctx.fillStyle = gradient; ctx.fillRect(0, 0, 1200, 675);
  ctx.fillStyle = '#b8d4ff'; ctx.font = 'bold 40px system-ui, sans-serif'; ctx.textAlign = 'right'; ctx.fillText('Hussein Badr English', 1090, 88);
  ctx.fillStyle = '#ffffff'; ctx.font = 'bold 72px system-ui, sans-serif'; ctx.fillText('نتيجة اختبار المستوى', 1090, 220);
  ctx.fillStyle = '#8fd6c4'; ctx.font = 'bold 110px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(String(result.level || 'A1'), 600, 375);
  ctx.fillStyle = '#ffffff'; ctx.font = '48px system-ui, sans-serif'; ctx.fillText(`${Number(result.percent) || 0}% — تقدير تعليمي`, 600, 448);
  const skills = result.bySkill || {}; const entries = Object.entries(skills).slice(0, 5);
  ctx.font = '25px system-ui, sans-serif'; ctx.fillStyle = '#d9e4ff'; ctx.textAlign = 'right';
  let y = 520; for (const [label, score] of entries) { ctx.fillText(`${label}: ${Math.round(Number(score) || 0)}%`, 1090, y); y += 32; }
  ctx.textAlign = 'left'; ctx.font = '23px system-ui, sans-serif'; ctx.fillText(location.origin + BASE_PATH, 55, 625);
  const blob = await new Promise((resolve, reject) => canvas.toBlob(value => value ? resolve(value) : reject(new Error('Could not create image')), 'image/png'));
  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'hussein-badr-english-result.png'; a.click(); URL.revokeObjectURL(url);
}
export async function shareResult(result, method = 'native') {
  const text = makeShareText(result); const url = `${location.origin}${BASE_PATH}`;
  if (method === 'whatsapp') window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
  else if (method === 'telegram') window.open(`https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
  else if (method === 'x') window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
  else if (method === 'copy') { await navigator.clipboard.writeText(`${text}\n${url}`); }
  else if (navigator.share) await navigator.share({ title: 'Hussein Badr English', text, url });
  else await navigator.clipboard.writeText(`${text}\n${url}`);
}

const PROGRESS_KEY = 'hbenglish:progress:v2';
const SRS_KEY = 'hbenglish:srs:v1';
const ONBOARD_KEY = 'hbenglish:onboarding:v1';
const DAY = 86400000;
const today = () => new Date().toLocaleDateString('en-CA');
function validProgress(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const dateOk = item => typeof item === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(item);
  const lessonsOk = Array.isArray(value.lessonsCompleted) && value.lessonsCompleted.length <= 100 && value.lessonsCompleted.every(item => typeof item === 'string' && /^[a-z0-9-]{2,60}$/.test(item));
  const daysOk = Array.isArray(value.activeDays) && value.activeDays.length <= 400 && value.activeDays.every(dateOk);
  const testsOk = Array.isArray(value.testHistory) && value.testHistory.length <= 30 && value.testHistory.every(row => row && typeof row === 'object' && dateOk(row.date) && typeof row.level === 'string' && ['A1','A2','B1','B2','C1'].includes(row.level) && Number.isFinite(row.percent) && row.percent >= 0 && row.percent <= 100 && (!row.bySkill || typeof row.bySkill === 'object'));
  return lessonsOk && daysOk && testsOk && Number.isFinite(value.points) && value.points >= 0 && value.points <= 100000;
}
function defaults() { return { version: 2, lessonsCompleted: [], testHistory: [], activeDays: [], points: 0, weeklyGoal: 5, lastActive: '', onboarding: null, badges: [] }; }
export function safeRead(key, fallback = null) {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; }
  catch { return fallback; }
}
function readProgress() {
  const item = safeRead(PROGRESS_KEY, null);
  return validProgress(item) ? { ...defaults(), ...item } : defaults();
}
function writeProgress(data) {
  try { localStorage.setItem(PROGRESS_KEY, JSON.stringify(data)); return true; }
  catch { return false; }
}
export function getProgress() { return readProgress(); }
export function markActivity() {
  const data = readProgress(); const stamp = today();
  if (!data.activeDays.includes(stamp)) data.activeDays.push(stamp);
  data.activeDays = [...new Set(data.activeDays)].sort().slice(-400);
  data.lastActive = stamp;
  const completed = new Set(data.lessonsCompleted);
  const tests = data.testHistory.length;
  const badges = [];
  if (completed.size >= 1) badges.push('first-lesson');
  if (completed.size >= 5) badges.push('five-lessons');
  if (tests >= 1) badges.push('first-test');
  const streak = calculateStreak(data.activeDays);
  if (streak >= 7) badges.push('seven-day-streak');
  data.badges = badges;
  writeProgress(data);
  return data;
}
export function calculateStreak(days = []) {
  const set = new Set(days); let cursor = new Date(`${today()}T12:00:00`); let count = 0;
  if (!set.has(today())) cursor = new Date(cursor.getTime() - DAY);
  while (set.has(cursor.toLocaleDateString('en-CA'))) { count++; cursor = new Date(cursor.getTime() - DAY); }
  return count;
}
export function completeLesson(id) {
  if (typeof id !== 'string' || !/^[a-z0-9-]{2,60}$/.test(id)) return readProgress();
  const data = markActivity();
  if (!data.lessonsCompleted.includes(id)) { data.lessonsCompleted.push(id); data.points += 10; }
  data.lessonsCompleted = [...new Set(data.lessonsCompleted)];
  return writeProgress(data) ? data : readProgress();
}
export function recordTest(result) {
  if (!result || typeof result !== 'object' || typeof result.level !== 'string' || typeof result.percent !== 'number') return readProgress();
  const data = markActivity();
  data.testHistory.push({ date: today(), timestamp: Date.now(), level: result.level.slice(0, 3), percent: Math.max(0, Math.min(100, result.percent)), bySkill: result.bySkill && typeof result.bySkill === 'object' ? result.bySkill : {} });
  data.testHistory = data.testHistory.slice(-30); data.points += 5;
  writeProgress(data); return data;
}
export function getSrs() {
  const value = safeRead(SRS_KEY, {});
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  const clean = {};
  for (const [key, row] of Object.entries(value)) {
    if (/^fc\d{3}$/.test(key) && row && typeof row === 'object' && Number.isInteger(row.box) && typeof row.due === 'string') {
      clean[key] = { box: Math.max(1, Math.min(5, row.box)), due: row.due, reviews: Number.isInteger(row.reviews) ? Math.max(0, row.reviews) : 0, last: typeof row.last === 'string' ? row.last : '' };
    }
  }
  return clean;
}
export function saveSrs(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  try { localStorage.setItem(SRS_KEY, JSON.stringify(value)); return true; } catch { return false; }
}
export function getOnboarding() { const v = safeRead(ONBOARD_KEY, null); return v && typeof v === 'object' && ['goal','level','minutes'].every(k => typeof v[k] === 'string') ? v : null; }
export function saveOnboarding(value) {
  if (!value || !['conversation','travel','work','exam','general'].includes(value.goal) || !['A1','A2','B1','B2','C1','unknown'].includes(value.level) || !['5','10','20','30'].includes(value.minutes)) return false;
  try { localStorage.setItem(ONBOARD_KEY, JSON.stringify(value)); const p = readProgress(); p.onboarding = value; writeProgress(p); return true; } catch { return false; }
}
export function exportAll() {
  return { exportedAt: new Date().toISOString(), format: 'hussein-badr-english-progress-v2', progress: readProgress(), spacedRepetition: getSrs(), onboarding: getOnboarding() };
}
export function resetAll() {
  try { localStorage.removeItem(PROGRESS_KEY); localStorage.removeItem(SRS_KEY); localStorage.removeItem(ONBOARD_KEY); localStorage.removeItem('hbenglish:placement:v2'); return true; }
  catch { return false; }
}

export const BASE_PATH = '/Hussien2009/';
export const TEXT = {
  ar: {
    menuOpen: 'فتح القائمة', menuClose: 'إغلاق القائمة', language: 'English', theme: 'تبديل المظهر',
    saved: 'تم الحفظ على هذا الجهاز.', error: 'تعذّر إكمال العملية. تحقّق من اتصالك ثم حاول مجددًا.',
    speechUnsupported: 'ميزة النطق غير مدعومة في هذا المتصفح. جرّب Chrome أو Edge أو استخدم النص المكتوب.',
    speechVoicesMissing: 'لم تتوفر أصوات إنجليزية في جهازك. تحقّق من إعدادات الصوت أو استخدم المتصفح الافتراضي.',
    copied: 'تم نسخ الرابط.', exportDone: 'تم تجهيز ملف تقدمك للتنزيل.', resetDone: 'تم حذف بيانات التقدم المحلية.',
    quizCorrect: 'إجابة صحيحة.', quizWrong: 'ليست الإجابة الصحيحة. راجع الشرح ثم حاول مرة أخرى.',
    selectAnswer: 'اختر إجابة أولًا.', level: 'المستوى',
    noData: 'لا توجد بيانات بعد. أكمل درسًا أو اختبارًا لبدء متابعة تقدمك.',
    micExplain: 'سيطلب المتصفح إذن الميكروفون لالتقاط إجابتك داخل الصفحة. لا يرفع هذا الموقع ملفًا صوتيًا ولا يحفظ تسجيلًا.',
    micDenied: 'لم يُمنح إذن الميكروفون. افتح إعدادات الموقع في المتصفح، اسمح بالميكروفون، ثم أعد تحميل الصفحة.',
    linkCopied: 'تم نسخ الرابط إلى الحافظة.'
  },
  en: {
    menuOpen: 'Open navigation', menuClose: 'Close navigation', language: 'العربية', theme: 'Toggle theme',
    saved: 'Saved on this device.', error: 'Could not complete the action. Check your connection and try again.',
    speechUnsupported: 'Speech is not supported in this browser. Try Chrome or Edge, or use the text alternative.',
    speechVoicesMissing: 'No English voices are available on this device. Check system speech settings or use the default browser voice.',
    copied: 'Link copied.', exportDone: 'Your progress file is ready to download.', resetDone: 'Local progress data was deleted.',
    quizCorrect: 'Correct answer.', quizWrong: 'That is not correct. Review the explanation and try again.',
    selectAnswer: 'Choose an answer first.', level: 'Level',
    noData: 'No progress yet. Complete a lesson or test to start tracking progress.',
    micExplain: 'Your browser will request microphone access to capture your response on this page. This site does not upload or retain an audio recording.',
    micDenied: 'Microphone access was not granted. Open your browser site settings, allow microphone access, then reload the page.',
    linkCopied: 'Link copied to the clipboard.'
  }
};
export function currentLanguage() {
  try { return localStorage.getItem('hbenglish:language') === 'en' ? 'en' : 'ar'; }
  catch { return 'ar'; }
}
export function applyLanguage(lang = currentLanguage()) {
  const selected = lang === 'en' ? 'en' : 'ar';
  try { localStorage.setItem('hbenglish:language', selected); } catch { /* Storage can be disabled. */ }
  document.documentElement.lang = selected;
  document.documentElement.dir = selected === 'ar' ? 'rtl' : 'ltr';
  document.querySelectorAll('[data-ar][data-en]').forEach((node) => {
    const value = node.getAttribute(selected === 'en' ? 'data-en' : 'data-ar');
    if (value !== null) node.textContent = value;
  });
  document.querySelectorAll('[data-language-toggle]').forEach((button) => {
    button.textContent = selected === 'ar' ? 'EN' : 'عربي';
    button.setAttribute('aria-label', selected === 'ar' ? 'Switch language to English' : 'تبديل اللغة إلى العربية');
  });
  document.querySelectorAll('[data-menu-toggle]').forEach((button) => {
    const expanded = button.getAttribute('aria-expanded') === 'true';
    button.setAttribute('aria-label', expanded ? TEXT[selected].menuClose : TEXT[selected].menuOpen);
  });
  const labelsEn = {
    'ابدأ الاختبار التكيفي':'Start adaptive test','ابدأ الاختبار الكامل':'Start full test','عرض المسارات':'View learning paths',
    'افتح لوحة التقدم':'Open progress dashboard','مكتبة الدروس':'Lesson library','ابدأ اختبار الاستماع':'Start listening test',
    'تحقق من الميكروفون':'Check microphone','ابدأ مهام التحدث':'Start speaking tasks',
    'احفظ هدف التعلم على هذا الجهاز':'Save my learning goal on this device','احفظ هدفك على هذا الجهاز':'Save your goal on this device',
    'علّم الدرس كمكتمل':'Mark lesson complete','تحقق من إجابات الاختبار المصغّر':'Check mini-quiz answers',
    'تصدير تقدمي JSON':'Export my progress JSON','حذف بيانات التقدم':'Delete progress data','إعادة الاختبار':'Retake test',
    'العودة إلى الرئيسية':'Back to home','افتح الدرس':'Open lesson','ابدأ اختبار مستوى الإنجليزي':'Take the placement test',
    'استكشف الدروس':'Explore lessons','ابدأ الاختبار':'Start test','ابدأ بموقف في المطعم':'Start with a restaurant lesson',
    'ابدأ مراجعة خمس دقائق':'Start a five-minute review','ابدأ التعلم':'Start learning','تابع القنوات':'Follow the channels',
    'اختبار مستوى الإنجليزي من A1 إلى C1':'English placement test: A1 to C1','اختر طريقة الاختبار':'Choose a test mode',
    'كيف تستخدم النتيجة؟':'How to use your result','أولًا: اختبار الاستماع':'Part 1: Listening test','ثانيًا: اختبار التحدث':'Part 2: Speaking test',
    'اختبر فهمك: 5 أسئلة':'Check your understanding: 5 questions','أهداف الدرس':'Lesson objectives',
    'المفردات الأساسية':'Key vocabulary','أمثلة يمكنك سماعها':'Listen to examples','حوار قصير':'Short dialogue',
    'بطاقات المفردات الإنجليزية':'English vocabulary flashcards','لوحة تقدمك في الإنجليزية':'Your English progress dashboard',
    'سياسة الخصوصية':'Privacy policy','الشروط والأحكام':'Terms and conditions','سجل تحديثات المنصة':'Website changelog',
    'عن Hussein Badr English':'About Hussein Badr English','تواصل مع Hussein Badr English':'Contact Hussein Badr English',
    'أكمل الدرس كمكتمل':'Mark lesson as complete','افتح رسالة البريد لإرسالها':'Open an email to send',
    'إعداد رسالة الاشتراك':'Prepare subscription email','تحقق من إجابات الاختبار المصغّر':'Check mini-quiz answers',
    'تثبيت التطبيق على الجهاز':'Install app on this device','الإبلاغ عن خطأ في هذا السؤال':'Report an error in this question',
    'الإبلاغ عن خطأ في الدرس':'Report a lesson error','افتح اختبار المهارات':'Open skills test','مراجعة كل البطاقات':'Review all cards',
    'اكشف المعنى':'Reveal meaning','استمع إلى الإنجليزية':'Listen to English','السؤال التالي':'Next question',
    'عرض النتيجة':'Show results','التالي ←':'Next →','→ السابق':'← Previous','التقييم التدريبي الحالي':'Current practice score'
  };
  const labelsAr = Object.fromEntries(Object.entries(labelsEn).map(([ar,en]) => [en,ar]));
  document.querySelectorAll('button, a, summary, h1, h2, h3, legend').forEach(node => {
    if (node.hasAttribute('data-ar') && node.hasAttribute('data-en')) return;
    const raw = node.dataset.labelAr || node.textContent.trim();
    if (labelsEn[raw] || labelsAr[raw]) {
      const arabic = labelsEn[raw] ? raw : labelsAr[raw];
      node.dataset.labelAr = arabic;
      node.textContent = selected === 'en' ? labelsEn[arabic] : arabic;
    }
  });
  document.querySelectorAll('[data-current-lang]').forEach((node) => { node.textContent = selected.toUpperCase(); });
  return selected;
}
export function tr(key) { return TEXT[currentLanguage()][key] || TEXT.ar[key] || key; }
